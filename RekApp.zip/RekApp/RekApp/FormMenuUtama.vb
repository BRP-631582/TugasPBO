﻿Imports System.Data.Odbc
Public Class FormMenuUtama
    Public Property stringpass As String

    Sub Terkunci()
        LoginToolStripMenuItem.Enabled = True
        LogoutToolStripMenuItem.Enabled = False
        MasterToolStripMenuItem.Enabled = False
        TransaksiToolStripMenuItem.Enabled = False
        UtilityToolStripMenuItem.Enabled = False

    End Sub
    Private Sub FormMenuUtama_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Terkunci()
        Label1.Visible = False
        Label2.Visible = False
        Label3.Visible = False
        Label5.Visible = False
    End Sub

    Private Sub LoginToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LoginToolStripMenuItem.Click
        FormLogin.ShowDialog()
    End Sub
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        End
    End Sub

    Private Sub LogoutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LogoutToolStripMenuItem.Click
        MsgBox("Anda telah berhasil Logout.", MessageBoxIcon.Information, "Peringatan")
        Call Terkunci()
    End Sub

    Private Sub AdminToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AdminToolStripMenuItem.Click
        FormMasterAdmin.ShowDialog()
    End Sub

    Private Sub FormMenuUtama_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        If LoginToolStripMenuItem.Enabled = False Then
            Label1.Text = stringpass
            If Label1.Text = "" Then
            Else
                Cmd = New OdbcCommand("Select * From tbl_admin where kodeadmin='" & Label1.Text & "'", Conn)
                Rd = Cmd.ExecuteReader
                Rd.Read()
                If Rd.HasRows Then
                    Label2.Text = Rd.Item("leveladmin")
                    Label3.Text = Rd.Item("namaadmin")
                End If
                If Label2.Text = "admin" Then
                    Label5.Text = "Selamat datang, admin "
                Else
                    Label5.Text = "Selamat datang, user "
                End If
                Label4.Text = Label5.Text & Label3.Text
            End If
        Else
            Label4.Text = "Silahkan Login terlebih dahulu."
        End If
    End Sub

    Private Sub DetailCustomerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DetailCustomerToolStripMenuItem.Click
        FormRiwayatCustomer.ShowDialog()
    End Sub

    Private Sub CRUDToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CRUDToolStripMenuItem.Click
        FormCustomer.ShowDialog()
    End Sub

    Private Sub TransaksiBaruToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TransaksiBaruToolStripMenuItem.Click
        FormTransaksi.ShowDialog()
    End Sub

    Private Sub GantiPasswordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GantiPasswordToolStripMenuItem.Click
        FormGantiPassword.ShowDialog()
    End Sub
End Class
