﻿Imports System.Data.Odbc
Public Class FormCustomer
    Sub kondisiawal()

        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()

        TextBox1.Enabled = False
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        TextBox4.Enabled = False
        DateTimePicker1.Enabled = False
        DateTimePicker1.Text = "1/1/1990"

        Button1.Enabled = True
        Button2.Enabled = True
        Button3.Enabled = True
        Button4.Enabled = True

        Button1.Text = "Input"
        Button2.Text = "Edit"
        Button3.Text = "Delete"
        Button4.Text = "Kembali"

        Call Koneksi()
        Da = New OdbcDataAdapter("Select nik, nama, ttl, alamat from tbl_customer", Conn)
        Ds = New DataSet
        Da.Fill(Ds, "tbl_customer")
        DataGridView1.DataSource = Ds.Tables("tbl_customer")
        DataGridView1.ReadOnly = True

    End Sub
    Sub siapisi()
        TextBox1.Enabled = True
        TextBox2.Enabled = True
        TextBox3.Enabled = True
        TextBox4.Enabled = True
        DateTimePicker1.Enabled = True
    End Sub

    Private Sub FormCustomer_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub FormCustomer_Load_1(sender As Object, e As EventArgs) Handles MyBase.Load
        Label6.Visible = False
        kondisiawal()
    End Sub
    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            e.Handled = Not (Char.IsDigit(e.KeyChar) Or e.KeyChar = ".")
        End If
        If e.KeyChar = Chr(13) And Button2.Enabled = True Or Button3.Enabled = True And e.KeyChar = Chr(13) Then
            Call Koneksi()
            Cmd = New OdbcCommand("Select * From tbl_customer where nik='" & TextBox1.Text & "'", Conn)
            Rd = Cmd.ExecuteReader
            Rd.Read()
            If Not Rd.HasRows Then
                MsgBox("NIK yang anda inputkan tidak terdaftar.", MessageBoxIcon.Warning, "Peringatan")
            Else
                TextBox2.Enabled = True
                TextBox3.Enabled = True
                TextBox4.Enabled = True
                DateTimePicker1.Enabled = True
                TextBox1.Text = Rd.Item("nik")
                TextBox2.Text = Rd.Item("nama")
                TextBox3.Text = Rd.Item("tempatlahir")
                TextBox4.Text = Rd.Item("alamat")
                DateTimePicker1.Text = Rd.Item("tgllahir")
            End If
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Button1.Text = "Input" Then
            Button1.Text = "Simpan"
            Button2.Enabled = False
            Button3.Enabled = False
            Button4.Text = "Batal"
            Call siapisi()
        Else
            If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Then
                MsgBox("Silahkan isi semua data customer secara lengkap", MessageBoxIcon.Stop, "Peringatan")
            Else
                Call Koneksi()
                Dim inputdata As String = "insert into tbl_customer values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & DateTimePicker1.Text & "','" & Label6.Text & "','" & TextBox4.Text & "')"
                Cmd = New OdbcCommand(inputdata, Conn)
                Cmd.ExecuteNonQuery()
                MsgBox("Anda berhasil Input Data.", , "Peringatan")
                Call kondisiawal()
            End If
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If Button4.Text = "Kembali" Then
            Me.Close()
        Else
            Call kondisiawal()
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Button2.Text = "Edit" Then
            Button2.Text = "Simpan"
            Button1.Enabled = False
            Button3.Enabled = False
            Button4.Text = "Batal"
            TextBox1.Enabled = True
        Else
            If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Then
                MsgBox("Silahkan isi semua data customer secara lengkap", MessageBoxIcon.Stop, "Peringatan")
            Else
                Call Koneksi()
                Dim updatedata As String = "update tbl_customer set nama='" & TextBox2.Text & "', tempatlahir='" & TextBox3.Text & "',tgllahir='" & DateTimePicker1.Text & "',ttl='" & Label6.Text & "',alamat='" & TextBox4.Text & "' where nik='" & TextBox1.Text & "'"
                Cmd = New OdbcCommand(updatedata, Conn)
                Cmd.ExecuteNonQuery()
                MsgBox("Anda berhasil Update Data.", , "Peringatan")
                Call kondisiawal()
            End If
        End If
    End Sub



    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        If Button3.Text = "Delete" Then
            Button3.Text = "Hapus"
            Button1.Enabled = False
            Button2.Enabled = False
            Button4.Text = "Batal"
            TextBox1.Enabled = True
            TextBox2.ReadOnly = True
            TextBox3.ReadOnly = True
            TextBox4.ReadOnly = True

        Else
            If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Then
                MsgBox("Silahkan isi semua data customer secara lengkap.", MessageBoxIcon.Stop, "Peringatan")
            Else
                Call Koneksi()
                Dim hapusdata As String = "delete from tbl_customer where nik='" & TextBox1.Text & "'"
                Cmd = New OdbcCommand(hapusdata, Conn)
                Cmd.ExecuteNonQuery()
                MsgBox("Anda berhasil Hapus Data Customer.", , "Peringatan")
                Call kondisiawal()
            End If
        End If
    End Sub

    Private Sub FormCustomer_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        Label6.Text = TextBox3.Text & ", " & DateTimePicker1.Text
    End Sub
End Class