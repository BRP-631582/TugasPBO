﻿Imports System.Data.Odbc
Imports System.Speech
Public Class FormGantiPassword
    Public Property getpw As String

    Private Sub FormGantiPassword_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        kondisiawal()
        Label4.Text = getpw
        Label4.Visible = False
        Label5.Visible = False
    End Sub
    Sub siapisi()
        TextBox1.Enabled = True
        TextBox2.Enabled = True
        TextBox3.Enabled = True
        Button1.Enabled = True
        Button2.Text = "Ubah"
        Button3.Text = "Batal"
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Button2.Text = "Change" Then
            Call siapisi()
        Else
            If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Then
                MsgBox("Isi data secara lengkap.", MessageBoxIcon.Error, "Peringatan")
            ElseIf TextBox1.Text = Label4.Text And TextBox3.Text = Label5.Text Then
                Call Koneksi()
                Dim updatepw = "update tbl_admin set passwordadmin = '" & TextBox2.Text & "'"
                Cmd = New OdbcCommand(updatepw, Conn)
                Cmd.ExecuteNonQuery()
                MsgBox("Anda berhasil Merubah Password.", , "Peringatan")
                Call kondisiawal()
            Else
                MsgBox("Data yang anda inputkan salah.", MessageBoxIcon.Error, "Peringatan")
            End If
        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim SAPI
        TextBox3.Clear()
        SAPI = CreateObject("SAPI.spvoice")
        Label5.Text = fivedigitrand()
        SAPI.speak(Label5.Text)

    End Sub
    Private Function fivedigitrand() As String
        Dim myrand As New Random
        Return myrand.Next(1, 99999).ToString("d5")
    End Function
    Sub kondisiawal()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox1.Enabled = False
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        Button1.Enabled = False
        Button2.Text = "Change"
        Button3.Text = "Kembali"
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If Button3.Text = "Batal" Then
            Call kondisiawal()
        Else
            Me.Close()
        End If
    End Sub
End Class