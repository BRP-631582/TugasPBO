﻿Imports System.Data.Odbc
Public Class FormTransaksi

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        ComboBox2.Items.Clear()
        ComboBox3.Items.Clear()
        If ComboBox1.Text = "Transaksi Masuk" Then
            Call siapisi()
            Button1.Enabled = True
            TextBox4.ReadOnly = False
            ComboBox2.Items.Add("Modal Usaha")
            TextBox2.Enabled = False
            TextBox3.Enabled = False
            TextBox5.Enabled = False
            ComboBox3.Enabled = False
            ComboBox3.Text = ""
        ElseIf ComboBox1.Text = "Transaksi Keluar" Then
            Call siapisi()
            Button1.Enabled = False
            ComboBox2.Items.Add("Valas Kertas")
            ComboBox2.Items.Add("Valas Koin")
            ComboBox2.Items.Add("Rupiah Rusak / Lama")
            TextBox4.ReadOnly = True
            TextBox1.Enabled = True
            TextBox2.Enabled = True
            TextBox3.Enabled = True
            TextBox5.Enabled = True
            ComboBox3.Enabled = True
        End If
    End Sub

    Private Sub FormTransaksi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call kondisiawal()
        Label8.Visible = False
        Label10.Visible = False
        Label11.Visible = False
        Label16.Visible = False
        Label17.Visible = False
        Label18.Visible = False
    End Sub
    Sub kondisiawal()
        Button1.Enabled = True
        ComboBox1.Items.Clear()
        ComboBox2.Items.Clear()
        ComboBox3.Items.Clear()
        ComboBox1.Enabled = False
        ComboBox2.Enabled = False
        ComboBox3.Enabled = False
        TextBox1.Enabled = False
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        TextBox4.Enabled = False
        TextBox5.Enabled = False
        Label13.Text = ""
        Label15.Text = ""
        Button1.Text = "Input"
        Button2.Text = "Kembali"
        Call siapisi()
        Call Koneksi()
        Da = New OdbcDataAdapter("Select kodetransaksi, keterangan, harga, kredit, debit, sisakas, nik, waktutransaksi from tbl_transaksi", Conn)
        Ds = New DataSet
        Da.Fill(Ds, "tbl_transaksi")
        DataGridView1.DataSource = Ds.Tables("tbl_transaksi")
        DataGridView1.ReadOnly = True

    End Sub
    Sub siapisi()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        TextBox5.Clear()
        ComboBox1.Text = ""
        ComboBox2.Text = ""
        ComboBox3.Text = ""
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim keterangan As String
        Dim kodetransaksi As String
        Call Koneksi()
        Dim sisa As String = "SELECT sisakas FROM (SELECT * FROM tbl_transaksi ORDER BY id DESC LIMIT 1) sub ORDER BY id ASC"
        Cmd = New OdbcCommand(sisa, Conn)
        Rd = Cmd.ExecuteReader()
        If Rd.HasRows Then
            Rd.Read()
            Label12.Text = Rd("sisakas")
        End If
        If TextBox2.Text = "" Or TextBox3.Text = "" Then
        Else
            Dim jumlah As Double
            Dim harga As Double
            Dim total As Double
            jumlah = Convert.ToDouble(TextBox2.Text)
            harga = Convert.ToDouble(TextBox3.Text)
            total = jumlah * harga
            TextBox4.Text = total
        End If
        kodetransaksi = Label10.Text & " - " & TextBox1.Text
        keterangan = TextBox2.Text & " " & ComboBox3.Text
        Label8.Text = kodetransaksi
        Label11.Text = keterangan
        If Button1.Text = "Input" Then
            Button1.Text = "Simpan"
            ComboBox1.Enabled = True
            ComboBox2.Enabled = True
            ComboBox3.Enabled = True
            TextBox1.Enabled = True
            TextBox2.Enabled = True
            TextBox3.Enabled = True
            TextBox4.Enabled = True
            TextBox5.Enabled = True
            Button2.Text = "Batal"
            ComboBox1.Items.Add("Transaksi Masuk")
            ComboBox1.Items.Add("Transaksi Keluar")
        ElseIf TextBox1.Text = "" Or TextBox4.Text = "" Or ComboBox2.Text = "" Then
            MsgBox("Silahkan isi semua data transaksi secara lengkap", MessageBoxIcon.Stop, "Peringatan")
        ElseIf Button1.Text = "Simpan" And ComboBox1.Text = "Transaksi Masuk" Then
            Call Koneksi()
            Dim sebelumsisakas As Double
            Dim sesudahsisakas As Double
            Dim total As Double = TextBox4.Text
            sebelumsisakas = Convert.ToDouble(Label12.Text)
            sesudahsisakas = total + sebelumsisakas
            Label13.Text = sesudahsisakas
            Label14.Text = "Modal Usaha"
            Dim inputdata As String = "insert into tbl_transaksi (kodetransaksi, keterangan, debit, sisakas) values ('" & Label8.Text & "','" & Label14.Text & "','" & TextBox4.Text & "','" & Label13.Text & "')"
            Cmd = New OdbcCommand(inputdata, Conn)
            Cmd.ExecuteNonQuery()
            MsgBox("Anda berhasil Input Data.", , "Peringatan")
            Call kondisiawal()
        ElseIf Button1.Text = "Simpan" And ComboBox1.Text = "Transaksi Keluar" Then
            Call Koneksi()
            cd = New OdbcCommand("Select * From tbl_customer where nik='" & TextBox5.Text & "'", Conn)
            Rd = cd.ExecuteReader
            Rd.Read()
            If Rd.HasRows Then
                Label16.Text = Rd.Item("nama")
                Label17.Text = Rd.Item("ttl")
                Label18.Text = Rd.Item("alamat")
            End If
            Dim sebelumsisakas As Double
            Dim sesudahsisakas As Double
            Dim total As Double = TextBox4.Text
            sebelumsisakas = Convert.ToDouble(Label12.Text)
            sesudahsisakas = sebelumsisakas - total
            Label15.Text = sesudahsisakas
            Dim inputdata As String = "insert into tbl_transaksi (kodetransaksi, jumlahuang, matauang, keterangan, harga, kredit, sisakas, nik, nama, ttl, alamat) values ('" & Label8.Text & "','" & TextBox2.Text & "','" & ComboBox3.Text & "','" & Label11.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & Label15.Text & "','" & TextBox5.Text & "','" & Label16.Text & "','" & Label17.Text & "','" & Label18.Text & "')"
            Cmd = New OdbcCommand(inputdata, Conn)
            Cmd.ExecuteNonQuery()
            MsgBox("Anda berhasil Input Data.", , "Peringatan")
            FormCetakTransaksi.ShowDialog()
            Call kondisiawal()
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Button2.Text = "Batal" Then
            Call kondisiawal()
        Else
            Me.Close()
        End If
    End Sub

    Private Sub ComboBox2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox2.SelectedIndexChanged
        If ComboBox2.Text = "Rupiah Rusak / Lama" Then
            ComboBox3.Items.Clear()
            ComboBox3.Items.Add("IDR")
        Else
            ComboBox3.Items.Clear()
            ComboBox3.Items.Add("USD")
            ComboBox3.Items.Add("SGD")
            ComboBox3.Items.Add("HKD")
            ComboBox3.Items.Add("SAR")
            ComboBox3.Items.Add("EUR")
            ComboBox3.Items.Add("JPY")
            ComboBox3.Items.Add("CNY")
        End If
        If ComboBox2.Text = "Valas Kertas" Then
            Label10.Text = "BBK"
        ElseIf ComboBox2.Text = "Valas Koin" Then
            Label10.Text = "BBC"
        ElseIf ComboBox2.Text = "Rupiah Rusak / Lama" Then
            Label10.Text = "BRL"
        ElseIf ComboBox2.Text = "Modal Usaha" Then
            Label10.Text = "MU"
        End If
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            e.Handled = Not (Char.IsDigit(e.KeyChar) Or e.KeyChar = ".")
        End If
    End Sub

    Private Sub TextBox3_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox3.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            e.Handled = Not (Char.IsDigit(e.KeyChar) Or e.KeyChar = ".")
        End If
    End Sub

    Private Sub TextBox4_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox4.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            e.Handled = Not (Char.IsDigit(e.KeyChar) Or e.KeyChar = ".")
        End If
    End Sub

    Private Sub TextBox5_KeyDown(sender As Object, e As KeyEventArgs) Handles TextBox5.KeyDown
        Call Koneksi()
        Dim inputdata As String = "SELECT nik FROM tbl_customer where nik='" & TextBox5.Text & "'"
        Cmd = New OdbcCommand(inputdata, Conn)
        Rd = Cmd.ExecuteReader()
        If e.KeyCode = Keys.Enter And Rd.HasRows Then
            MsgBox("NIK Customer yang anda inputkan sudah terdaftar.", , "Peringatan")
            Button1.Enabled = True
        ElseIf e.KeyCode = Keys.Enter Then
            Dim ask As MsgBoxResult = MsgBox("NIK yang anda inputkan belum terdaftar, apakah anda ingin mendaftarkannya terlebih dahulu?", MsgBoxStyle.YesNo, "Peringatan")
            If ask = MsgBoxResult.Yes Then
                FormCustomer.ShowDialog()
            Else : Button1.Enabled = False
            End If
        End If
    End Sub
    Private Sub TextBox5_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox5.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            e.Handled = Not (Char.IsDigit(e.KeyChar) Or e.KeyChar = ".")
        End If
    End Sub

    Private Sub TextBox2_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox2.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            e.Handled = Not (Char.IsDigit(e.KeyChar) Or e.KeyChar = ".")
        End If
    End Sub


    Private Sub FormTransaksi_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove


    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub
End Class