﻿Public Class FormCetakTransaksi

    Private Sub FormCetakTransaksi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Refresh()
        'TODO: This line of code loads data into the 'DSCetakTransaksi.DataTable1' table. You can move, or remove it, as needed.
        Me.DataTable1TableAdapter.Fill(Me.DSCetakTransaksi.DataTable1)
        Me.ReportViewer1.SetDisplayMode(Microsoft.Reporting.WinForms.DisplayMode.PrintLayout)
    End Sub

    Private Sub ReportViewer1_Load(sender As Object, e As EventArgs) Handles ReportViewer1.Load
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
    End Sub
End Class