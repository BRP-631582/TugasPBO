﻿Imports System.Data.Odbc
Public Class FormRiwayatCustomer
    Sub kondisiawal()
        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        TextBox4.Clear()
        DataGridView1.DataSource = Nothing
        Button2.Text = "Kembali"
    End Sub
    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            e.Handled = Not (Char.IsDigit(e.KeyChar) Or e.KeyChar = ".")
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Call Koneksi()
        Cmd = New OdbcCommand("Select * From tbl_customer where nik='" & TextBox1.Text & "'", Conn)
        Rd = Cmd.ExecuteReader
        Rd.Read()
        If Not Rd.HasRows Then
            MsgBox("NIK yang anda inputkan tidak terdaftar.", MessageBoxIcon.Warning, "Peringatan")
            TextBox1.Focus()
        Else
            TextBox1.Text = Rd.Item("nik")
            TextBox2.Text = Rd.Item("nama")
            TextBox3.Text = Rd.Item("ttl")
            TextBox4.Text = Rd.Item("alamat")
            Button2.Text = "Clear"
            Da = New OdbcDataAdapter("Select kodetransaksi, keterangan, kredit, waktutransaksi from tbl_transaksi where nik='" & TextBox1.Text & "'", Conn)
            Ds = New DataSet
            Da.Fill(Ds, "tbl_transaksi")
            DataGridView1.DataSource = Ds.Tables("tbl_transaksi")
            DataGridView1.ReadOnly = True


        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Button2.Text = "Clear" Then
            kondisiawal()
        Else
            Me.Close()
        End If
    End Sub

    Private Sub FormRiwayatCustomer_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class