﻿Imports System.Data.Odbc
Public Class FormMasterAdmin
    Sub kondisiawal()

        TextBox1.Clear()
        TextBox2.Clear()
        TextBox3.Clear()
        ComboBox1.Items.Clear()
        ComboBox1.Text = ""

        TextBox1.Enabled = False
        TextBox2.Enabled = False
        TextBox3.Enabled = False
        ComboBox1.Enabled = False

        Button1.Enabled = True
        Button2.Enabled = True
        Button3.Enabled = True
        Button4.Enabled = True

        Button1.Text = "Input"
        Button2.Text = "Edit"
        Button3.Text = "Delete"
        Button4.Text = "Kembali"

        Call Koneksi()
        Da = New OdbcDataAdapter("Select kodeadmin, namaadmin, leveladmin from tbl_admin", Conn)
        Ds = New DataSet
        Da.Fill(Ds, "tbl_admin")
        DataGridView1.DataSource = Ds.Tables("tbl_admin")
        DataGridView1.ReadOnly = True

    End Sub
    Sub siapisi()
        TextBox1.Enabled = True
        TextBox2.Enabled = True
        TextBox3.Enabled = True
        ComboBox1.Enabled = True
        ComboBox1.Items.Add("admin")
        ComboBox1.Items.Add("user")

    End Sub
    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub FormMasterAdmin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call kondisiawal()

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If Button4.Text = "Kembali" Then
            Me.Close()
        Else
            Call kondisiawal()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Button1.Text = "Input" Then
            Button1.Text = "Simpan"
            Button2.Enabled = False
            Button3.Enabled = False
            Button4.Text = "Batal"
            Call siapisi()
        Else
            If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or ComboBox1.Text = "" Then
                MsgBox("Silahkan isi semua data secara lengkap", MessageBoxIcon.Stop, "Peringatan")
            Else
                Call Koneksi()
                Dim inputdata As String = "insert into tbl_admin values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & ComboBox1.Text & "')"
                Cmd = New OdbcCommand(inputdata, Conn)
                Cmd.ExecuteNonQuery()
                MsgBox("Anda berhasil Input Data.", , "Peringatan")
                Call kondisiawal()
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Button2.Text = "Edit" Then
            Button2.Text = "Simpan"
            Button1.Enabled = False
            Button3.Enabled = False
            Button4.Text = "Batal"
            Call siapisi()
            TextBox2.Enabled = False
            TextBox3.Enabled = False
            ComboBox1.Enabled = False
        Else
            If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or ComboBox1.Text = "" Then
                MsgBox("Silahkan isi semua data secara lengkap", MessageBoxIcon.Stop, "Peringatan")
            Else
                Call Koneksi()
                Dim updatedata As String = "update tbl_admin set namaadmin='" & TextBox2.Text & "', passwordadmin='" & TextBox3.Text & "',leveladmin='" & ComboBox1.Text & "' where kodeadmin='" & TextBox1.Text & "'"
                Cmd = New OdbcCommand(updatedata, Conn)
                Cmd.ExecuteNonQuery()
                MsgBox("Anda berhasil Update Data.", , "Peringatan")
                Call kondisiawal()
            End If
        End If
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) And Button2.Enabled = True Then
            Call Koneksi()
            Cmd = New OdbcCommand("Select * From tbl_admin where kodeadmin='" & TextBox1.Text & "'", Conn)
            Rd = Cmd.ExecuteReader
            Rd.Read()
            If Not Rd.HasRows Then
                MsgBox("Kode Admin yang anda inputkan tidak terdaftar.", MessageBoxIcon.Warning, "Peringatan")
                TextBox1.Clear()
            Else
                TextBox2.Enabled = True
                TextBox3.Enabled = True
                ComboBox1.Enabled = True
                TextBox1.Text = Rd.Item("kodeadmin")
                TextBox2.Text = Rd.Item("namaadmin")
                TextBox3.Text = Rd.Item("passwordadmin")
                ComboBox1.Text = Rd.Item("leveladmin")
            End If
        ElseIf e.KeyChar = Chr(13) And Button3.Enabled = True Then
            Call Koneksi()
            Cmd = New OdbcCommand("Select * From tbl_admin where kodeadmin='" & TextBox1.Text & "'", Conn)
            Rd = Cmd.ExecuteReader
            Rd.Read()
            If Not Rd.HasRows Then
                MsgBox("Kode Admin yang anda inputkan tidak terdaftar.", MessageBoxIcon.Warning, "Peringatan")
                TextBox1.Clear()
            Else
                TextBox1.Text = Rd.Item("kodeadmin")
                TextBox2.Text = Rd.Item("namaadmin")
                TextBox3.Text = Rd.Item("passwordadmin")
                ComboBox1.Text = Rd.Item("leveladmin")
            End If
        End If
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If Button3.Text = "Delete" Then
            Button3.Text = "Hapus"
            Button1.Enabled = False
            Button2.Enabled = False
            Button4.Text = "Batal"
            Call siapisi()
            TextBox2.Enabled = False
            TextBox3.Enabled = False
            ComboBox1.Enabled = False
        Else
            If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or ComboBox1.Text = "" Then
                MsgBox("Silahkan isi semua data secara lengkap", MessageBoxIcon.Stop, "Peringatan")
            Else
                Call Koneksi()
                Dim hapusdata As String = "delete from tbl_admin where kodeadmin='" & TextBox1.Text & "'"
                Cmd = New OdbcCommand(hapusdata, Conn)
                Cmd.ExecuteNonQuery()
                MsgBox("Anda berhasil Hapus Data.", , "Peringatan")
                Call kondisiawal()
            End If
        End If
    End Sub

End Class