﻿Imports System.Data.Odbc
Public Class FormLogin
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
    End Sub
    Sub userterbuka()
        FormMenuUtama.LoginToolStripMenuItem.Enabled = False
        FormMenuUtama.LogoutToolStripMenuItem.Enabled = True
        FormMenuUtama.MasterToolStripMenuItem.Enabled = True
        FormMenuUtama.TransaksiToolStripMenuItem.Enabled = True
        FormMenuUtama.UtilityToolStripMenuItem.Enabled = True
        FormMenuUtama.AdminToolStripMenuItem.Enabled = False
    End Sub
    Sub adminterbuka()
        FormMenuUtama.LoginToolStripMenuItem.Enabled = False
        FormMenuUtama.LogoutToolStripMenuItem.Enabled = True
        FormMenuUtama.MasterToolStripMenuItem.Enabled = True
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Call Koneksi()
        FormMenuUtama.stringpass = TextBox1.Text
        FormGantiPassword.getpw = TextBox2.Text
        Cmd = New OdbcCommand("Select * from tbl_admin where kodeadmin ='" & TextBox1.Text & "' and passwordadmin ='" & TextBox2.Text & "'", Conn)
        Rd = Cmd.ExecuteReader
        Rd.Read()
        If Rd.HasRows Then
            If Rd.Item("leveladmin") = "admin" Then
                Call adminterbuka()
                MsgBox("Anda telah berhasil Login.", MessageBoxIcon.Information, "Peringatan")
                TextBox1.Clear()
                TextBox2.Clear()
                Me.Close()
            Else
                Call userterbuka()
                MsgBox("Anda telah berhasil Login.", MessageBoxIcon.Information, "Peringatan")
                TextBox1.Clear()
                TextBox2.Clear()
                Me.Close()
            End If
        Else
            MsgBox("Username atau Password yang Anda Inputkan Salah.", MessageBoxIcon.Error, "Peringatan")
            TextBox1.Clear()
            TextBox2.Clear()
        End If
    End Sub

    Private Sub FormLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class