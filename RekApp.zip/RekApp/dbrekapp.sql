-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2020 at 05:25 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbrekapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `kodeadmin` varchar(10) NOT NULL,
  `namaadmin` varchar(50) NOT NULL,
  `passwordadmin` varchar(30) NOT NULL,
  `leveladmin` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`kodeadmin`, `namaadmin`, `passwordadmin`, `leveladmin`) VALUES
('ADM001', 'Raka', '4321', 'admin'),
('USER001', 'Zaki', '4321', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `nik` bigint(16) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `tempatlahir` varchar(50) NOT NULL,
  `tgllahir` varchar(50) NOT NULL,
  `ttl` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_customer`
--

INSERT INTO `tbl_customer` (`nik`, `nama`, `tempatlahir`, `tgllahir`, `ttl`, `alamat`) VALUES
(3302251110930003, 'Bilardo Raka Pamungkas', 'Purwokerto', '1/1/1990', 'Purwokerto, 1/1/1990', 'Jl. Pasar Manis No.03 RT/RW 001/006 Kedungwuluh Purwokerto Barat'),
(3302251110970001, 'Agust Martinus', 'Purwokerto', '7/10/1997', 'Purwokerto, 7/10/1997', 'Jl. Diponegoro No.001 RT/RW 005/002 Cirebon');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_transaksi`
--

CREATE TABLE `tbl_transaksi` (
  `id` int(11) NOT NULL,
  `kodetransaksi` varchar(20) NOT NULL,
  `jumlahuang` int(11) DEFAULT NULL,
  `matauang` varchar(50) DEFAULT NULL,
  `keterangan` varchar(50) DEFAULT NULL,
  `harga` int(11) DEFAULT NULL,
  `kredit` int(11) NOT NULL,
  `debit` int(11) NOT NULL,
  `sisakas` int(11) NOT NULL,
  `nik` bigint(16) DEFAULT NULL,
  `nama` varchar(50) NOT NULL,
  `ttl` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `waktutransaksi` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_transaksi`
--

INSERT INTO `tbl_transaksi` (`id`, `kodetransaksi`, `jumlahuang`, `matauang`, `keterangan`, `harga`, `kredit`, `debit`, `sisakas`, `nik`, `nama`, `ttl`, `alamat`, `waktutransaksi`) VALUES
(103, 'MU - 001', NULL, NULL, 'Modal Usaha', NULL, 0, 10000000, 10000000, NULL, '', '', '', '2020-07-28 19:13:14'),
(104, 'BBK - 002', 100, 'USD', '100 USD', 15000, 1500000, 0, 8500000, 3302251110930003, 'Bilardo Raka Pamungkas', 'Purwokerto, 1/1/1990', 'Jl. Pasar Manis No.03 RT/RW 001/006 Kedungwuluh Purwokerto Barat', '2020-07-28 19:17:52'),
(105, 'BBK - 003', 200, 'SGD', '200 SGD', 10000, 2000000, 0, 6500000, 3302251110930003, 'Bilardo Raka Pamungkas', 'Purwokerto, 1/1/1990', 'Jl. Pasar Manis No.03 RT/RW 001/006 Kedungwuluh Purwokerto Barat', '2020-07-28 19:20:11'),
(106, 'BBC - 004', 10, 'EUR', '10 EUR', 18000, 180000, 0, 6320000, 3302251110970001, 'Agust Martinus', 'Purwokerto, 7/10/1997', 'Jl. Diponegoro No.001 RT/RW 005/002 Cirebon', '2020-07-28 19:23:03'),
(107, 'MU - 005', NULL, NULL, 'Modal Usaha', NULL, 0, 2000000, 8320000, NULL, '', '', '', '2020-07-28 19:24:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`kodeadmin`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`nik`);

--
-- Indexes for table `tbl_transaksi`
--
ALTER TABLE `tbl_transaksi`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kodetransaksi` (`kodetransaksi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_transaksi`
--
ALTER TABLE `tbl_transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
